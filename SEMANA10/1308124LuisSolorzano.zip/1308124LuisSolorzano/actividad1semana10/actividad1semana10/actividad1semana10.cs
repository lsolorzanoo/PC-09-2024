﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actividad1semana10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Ingrese un numero para calcular factorial");
                int numero = int.Parse(Console.ReadLine());
                int Factorial = CalcularFactorial(numero);
                Console.WriteLine($"El factorial de {numero} es {CalcularFactorial(numero)}");
            }
        }

        static public int CalcularFactorial(int numero)
        {
            if (numero == 0)
            {
                return 1;
            }
            else
            {
                int factorial = 1;
                for (int i = 1; i <= numero; i++)
                {
                    factorial *= i;
                }
                return factorial;
            }
        }
    }
}
