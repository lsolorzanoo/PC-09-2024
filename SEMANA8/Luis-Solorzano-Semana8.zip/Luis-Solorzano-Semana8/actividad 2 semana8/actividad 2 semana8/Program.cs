﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actividad_2_semana8
{
    class Program
    {
        static void Main(string[] args)
        {
            bool continuar = true;
            while (continuar)
            {
                Console.WriteLine("Ingrese un número no mayor a 6 cifras:");
                int num = Convert.ToInt32(Console.ReadLine());

                if (EsPrimo(num))
                {
                    Console.WriteLine("El número es primo.");
                }
                else
                {
                    Console.WriteLine("El número no es primo.");
                }


            }
        }

        static bool EsPrimo(int num)
        {
            if (num <= 1)
            {
                return false;
            }

            if (num == 2)
            {
                return true;
            }

            if (num % 2 == 0)
            {
                return false;
            }

            int raiz = (int)Math.Sqrt(num);
            for (int i = 3; i <= raiz; i += 2)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
